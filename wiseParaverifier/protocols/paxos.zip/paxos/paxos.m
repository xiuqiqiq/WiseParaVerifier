const
  NODENUMS : 4;
  VALUENUMS : 2;
  QUORUMNUMS : 2;
  ROUNDNUMS : 2;

type
  node : scalarset(NODENUMS);
  value : scalarset(VALUENUMS);
  quorum : scalarset(QUORUMNUMS);
  round : scalarset(ROUNDNUMS);
  one_b_max_vote_idx : array[round] of array[value] of boolean;
  vote_idx : array[value] of boolean;
  decision_idx : array[value] of boolean;

var
  none: round;
  le: array[round] of array[round] of boolean;
  member: array[node] of array[quorum] of boolean;
  one_a: array[round] of boolean;
  one_b_max_vote: array[node] of array[round] of one_b_max_vote_idx;
  one_b: array[node] of array[round] of boolean;
  left_rnd: array[node] of array[round] of boolean;
  proposal: array[round] of array[value] of boolean;
  vote: array[node] of array[round] of vote_idx;
  decision: array[node] of array[round] of decision_idx;


-- none is random from 1..ROUNDNUMS
startstate "Init"
  for R1: round do
    one_a[R1] := false;
  for N: node do
    one_b[N][R1] := false;
    left_rnd[N][R1] := false;
  for V: value do
    proposal[R1][V] := false;
    vote[N][R1][V] := false;
    decision[N][R1][V] := false;
  for R2: round do
    one_b_max_vote[N][R1][R2][V] := false;
  end;
  end;
  end;
  end;
endstartstate;



ruleset r: round do
rule "send_a"
  none != r
==>
begin
  one_a[r] := true;


endrule;endruleset;

ruleset n: node; r: round; maxr:round; v:value do
rule "join_round_case1"
  none != r & one_a[r] = true & left_rnd[n][r] = false & 
  none = maxr & forall MAXR: round do forall V: value do
  !(le[r][MAXR]=false & vote[n][MAXR][V] = true) end end
==>
begin
  one_b_max_vote[n][r][maxr][v] := true;
  one_b[n][r] := true;
 
  for R:round do
    if (left_rnd[n][R]=true | le[r][R]=false) then
      left_rnd[n][R] := true;
    else
      left_rnd[n][R] := false;
    end;
  end;

endrule;endruleset;


ruleset n: node; r: round; maxr:round; v:value do
rule "join_round_case2"
  none != r & one_a[r] = true & left_rnd[n][r] = false & 
  none != maxr & le[r][maxr] = false & vote[n][maxr][v]=true & 
  forall MAXR: round do forall V: value do
  (le[r][MAXR]=false & vote[n][MAXR][V] = true) -> le[MAXR][maxr]=true end end
==>
begin
  one_b_max_vote[n][r][maxr][v] := true;
  one_b[n][r] := true;

  for R:round do
    if (left_rnd[n][R]=true | le[r][R]=false) then
      left_rnd[n][R] := true;
    else
      left_rnd[n][R] := false;
    end;
  end;


endrule;endruleset;


ruleset  r: round; q:quorum; maxr:round; v:value do
rule "propose_case1"
  none != r & forall V:value do proposal[r][V]=false end & 
  forall N:node do member[N][q]=true -> one_b[N][r]=true end & 
  none = maxr & forall N:node do forall MAXR:round do forall V:value do 
  !(member[N][q]=true & le[r][MAXR] = false & vote[N][MAXR][V]=true) end end end
==>
begin
  proposal[r][v] := true;

endrule;endruleset;


ruleset  r: round; q:quorum; maxr:round; v:value do
rule "propose_case2"
  none != r & forall V:value do proposal[r][V]=false end & 
  forall N:node do member[N][q]=true -> one_b[N][r]=true end & 
  none != maxr & !forall N:node do !(member[N][q]=true & le[r][maxr]=false & vote[N][maxr][v]=true) end & 
  forall N:node do forall MAXR:round do forall V:value do 
  (member[N][q]=true & le[r][MAXR] = false & vote[N][MAXR][V]=true) -> le[MAXR][maxr]=true end end end
==>
begin
  proposal[r][v] := true;

endrule;endruleset;


ruleset  n: node; v:value; r:round do
rule "cast_vote"
  none != r & left_rnd[n][r]=false & proposal[r][v]=true
==>
begin
  vote[n][r][v] := true;

endrule;endruleset;




ruleset  n: node; v:value; r:round; q:quorum do
rule "decide"
  none != r & forall N:node do member[N][q]=true -> vote[N][r][v]=true end
==>
begin
  decision[n][r][v] := true;

endrule;endruleset;


invariant "onevalue"
forall N1:node do forall N2:node do forall R1:round do forall R2:round do forall V1:value do forall V2:value do 
  V1 != V2 ->
  !(decision[N1][R1][V1]=true & decision[N2][R2][V2]=true)
end end end end end end;




axiom "members"
forall X : quorum do forall Y : quorum do exists N : node do 
  member[N][X] = true & member[N][Y] = true
end end end;


axiom "total_order_1"
forall X: round do
  le[X][X] = true
end;


axiom "total_order_2"
forall X: round do forall Y: round do forall Z: round do
  le[X][Y] = true & le[Y][Z] = true -> le[X][Z] = true
end end end;


axiom "total_order_3"
forall X: round do forall Y: round do
  le[X][Y] = true & le[Y][X] = true -> X = Y
end end;


axiom "total_order_4"
forall X: round do forall Y: round do
  le[X][Y] = true | le[Y][X] = true
end end;